drop trigger atri_myhometotcount_ins;
drop trigger atri_myhometotcount_ups;