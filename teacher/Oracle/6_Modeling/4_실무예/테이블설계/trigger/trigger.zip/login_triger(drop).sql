drop trigger atri_humember_ins;
drop trigger atri_humember_upd;