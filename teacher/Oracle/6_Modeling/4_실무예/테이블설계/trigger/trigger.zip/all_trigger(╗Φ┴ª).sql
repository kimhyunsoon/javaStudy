drop trigger atri_humember_ins;
drop trigger atri_humember_upd;
drop trigger atri_myhomescrap_ins;

drop trigger atri_myhometotcount_ins;
drop trigger atri_myhometotcount_ups;

drop trigger atri_myhomegiftcount_ins;